function displayIfchildisabletoridetherollercoaster() {
    var childheight = 66;
    if (childheight > 52) {
        console.log("Get on that ride kiddo!");
    }
    else {
        console.log("Sorry kiddo, maybe next year.");
    }
}